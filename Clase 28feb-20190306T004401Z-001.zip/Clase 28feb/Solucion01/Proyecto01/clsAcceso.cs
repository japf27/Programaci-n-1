﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Proyecto01;

namespace Proyecto01
{
    class clsAcceso
    {
        

    }
}
