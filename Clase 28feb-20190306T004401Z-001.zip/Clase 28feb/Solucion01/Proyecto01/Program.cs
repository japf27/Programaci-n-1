﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto01
{
    class Program
    {
        public int ValorA,ValorB;
        private int ValorC;
        static void Main(string[] args)
        {
            int a;
            double b;
            Program obj = new Program();
            Console.WriteLine("Ingrese su nombre");
            obj.Nombre(Console.ReadLine());
            Console.WriteLine("Ingrese su apellido");
            obj.Apelligo(Console.ReadLine());
            Console.WriteLine("Ingrese su estatura");
            b = double.Parse(Console.ReadLine());
            obj.Statura(b);
            Console.WriteLine("Ingrese su edad");
            a = int.Parse(Console.ReadLine());
            obj.edad(a);

            Console.WriteLine(obj.Mamiferos());
            Console.ReadKey();


        }
        public int setValorA(int Dato)
        {
            ValorA=Dato;
            return ValorA;
        }
        public void getValorA()
        {

        }

        string Nombre(string Nombre)
        {
            return Nombre;
        }

        string Apelligo(string Apellido)
        {
            return Apellido;
        }

        double Statura(double estatura)
        {
            return estatura;
        }

        int edad(int edad)
        {
            return edad;
        }

        string Mamiferos()
        {
            return  "Ballena\n"+
                    "Caballo\n"+
                    "Chimpancé\n"+
                    "Delfín\n"+
                "Elefante\n"+
                "Gato\n"+
                "Gorila\n"+ 
                "Hipopótamo\n"+ 
                "Jirafa\n"+ 
                "León marino\n"+
                "León\n"+
                "Murciélago\n"+
                "Nutrias\n"+
                "Ornitorrinco\n"+ 
                "Oso polar\n"+
                "Rinoceronte\n"+
                "Ser humano\n"+ 
                "Tigre\n"+
                "Zorro\n"+ 
                "Perro\n"; 

        }
    }

}
